#!/bin/bash

if [ ! -d output ]
then
    mkdir output
fi

chr=$1
file=$2
pval=$3 # 0.05 / 1E-5
scale=$4
annots=$5
name=`echo $file | sed 's/\.ma//g'`

if [ ! -e  output/${name}.${pval}.jma.cojo ]
then
    /well/PROCARDIS/cgrace/GCTA-COJO/gcta_1.92.4beta/gcta64 \
	--bfile ukbb_bimfiles/ukb_v3_imp_${chr}_afr_snptest \
	--chr ${chr} \
	--cojo-file ${file}  \
	--cojo-slct \
	--out output/${name}.${pval} \
	--cojo-p $pval \
	--cojo-collinear 0.9
fi

for annot in `echo $annots | sed 's/,/\n/g'`
do
    echo $annot ${name}.${annot}.${scale}.ma

    if [ -e ${name}.${annot}.${scale}.ma ]
    then
	if [ ! -e  output/${name}.${annot}.${scale}.${pval}.jma.cojo ]
	then
    	    /well/PROCARDIS/cgrace/GCTA-COJO/gcta_1.92.4beta/gcta64 \
    		--bfile ukbb_bimfiles/ukb_v3_imp_${chr}_afr_snptest \
    		--chr ${chr} \
    		--cojo-file ${name}.${annot}.${scale}.ma  \
    		--cojo-slct \
    		--out output/${name}.${annot}.${scale}.${pval} \
    		--cojo-p $pval \
    		--cojo-collinear 0.9
	fi
    fi
done

