#!/usr/bin/perl
$|++;

use strict;
use warnings;
use Data::Dumper;

my %snphash = ();

open(my $SNPS, "snps_in_HyPrColoc.txt");

while(my $snp = <$SNPS>){
    chomp $snp;
    $snp=~/(.*)\:(.*)\_(.*)\_(.*)/;
    my $snp2=$1.":".$2."_".$4."_".$3;

    $snphash{$snp}{"init"}++;
    $snphash{$snp2}{"init2"}++;
}

close($SNPS);

#print Dumper(%snphash);

my $gzfile=$ARGV[0]; my $prefix=$ARGV[1];

open(my $F, "zcat $gzfile |");
open(my $O1, "> $prefix.metal.txt");
open(my $O2, "> $prefix.HyPr.metal.txt");

print $O1 "MarkerName\tP-value\n";
print $O2 "MarkerName\tP-value\n";
my $h = <$F>; chomp $h; my @h = split "\t", $h;
my %h = (); for(my $i = 0; $i < scalar(@h); $i++){$h{$h[$i]}=$i;}

#print Dumper(%h);

sub getval{
    my $keys=$_[0];
    my $arr=$_[1];
    my @ret = ();

    foreach my $key (@{$keys}){
    	push @ret, $$arr[$h{$key}];
    }

    return @ret;
}

#my $tot=`zcat $ARGV[0] | wc -l`; chomp $tot;
#print STDERR "$tot\n";
#my $c = 0;

while(my $l = <$F>){
 #   if(($c%1000)==0){print STDERR "$c of $tot\r";} $c++;

    chomp $l;
    my @d = split "\t", $l;
    my @in = ("snp", "pval", "chr", "bp", "a1", "a2");
    my ($snp, $p, $chr, $bp, $a1, $a2) = &getval(\@in, \@d);
    my $snptest = $chr.":".$bp."_".$a1."_".$a2;
    
    if(exists($snphash{$snptest})){
	print $O2 "$snp\t$p\n";
    }

    print $O1 "$snp\t$p\n";
}

close($F);
