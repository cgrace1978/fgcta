#!/usr/bin/perl

use strict;
use warnings;

## SNP A1 A2 freq b se p N chr bp
## A1 - Effect Allele
## freq - frequency of effect allele.

## Chr     SNP     bp      A1      A2      Freq    b       se      p       N
## A1 - Effect Allele.
open(my $F, $ARGV[0]);
my $name = $ARGV[0]; $name=~s/\.txt//g; $name=~s/working\///g;
open(my $O, ">".$name.".ma");
print $O "SNP A1 A2 freq b se p N chr bp\n";
<$F>;
while(my $l = <$F>){
    chomp $l;
    my ($chr, $snp, $bp, $a1, $a2, $freq, $b, $se, $p, $N) = split "\t", $l;
    print $O "$snp $a1 $a2 $freq $b $se $p $N $chr $bp\n";
}

close($F);
close($O);
