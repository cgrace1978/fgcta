#!/bin/bash

sno=$1
file=`grep -w ^$sno in.ma.txt1 | cut -f 2`;
chr=`grep -w ^$sno in.ma.txt1 | cut -f 3`;
st=`grep -w ^$sno in.ma.txt1 | cut -f 5`;
en=`grep -w ^$sno in.ma.txt1 | cut -f 6`;
name=`echo $file | sed 's/\.txt//g'`
echo $file $name $chr $st $en;

#perl pipeline/get.metal2.pl $name.b37.ukbb_aligned.ma $chr
## TODO use the AFR ref panel

#cat $name.LZ.snps.txt

bash /well/PROCARDIS/bin/locuszoom/results/run.ag.coord.wtitle.wsnps.bash \
    LZ/${name}.b37.ukbb_aligned.wsnps \
    $chr $st $en \
    LZ/$name.b37.ukbb_aligned.metal \
    "${name}" \
    $name.LZ.snps.txt

# bash /well/PROCARDIS/bin/locuszoom/results/run.ag.coord.wtitle.wsnps.bash \
#     LZ/${name}.b37.ukbb_aligned.HUDEP-2 \
#     $chr $st $en \
#     LZ/$name.b37.ukbb_aligned.HUDEP-2.x2_5.metal \
#     "${name} HUDEP-2"

# bash /well/PROCARDIS/bin/locuszoom/results/run.ag.coord.wtitle.wsnps.bash \
#     LZ/${name}.b37.ukbb_aligned.E123 \
#     $chr $st $en \
#     LZ/$name.b37.ukbb_aligned.E123.x2_5.metal \
#     "${name} E123"
