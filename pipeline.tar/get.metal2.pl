#!/usr/bin/perl

use strict;
use warnings;
use Data::Dumper;

my %hash = ();
my %ordered = ();

my $file = $ARGV[0];
my $name = $file; $name=~s/\.ma//g;
my $chr = $ARGV[1];

## SNP A1 A2 freq b se p N chr bp
open(my $F1, $ARGV[0]);

<$F1>;
while(my $l = <$F1>){
    chomp $l;
    my @d = split " ", $l;
    my $snp = $d[0]; my $p = $d[6];
    my $bp = $d[9];

    $hash{$snp}{"snptest"}=$snp;
    $hash{$snp}{"p"}=$p;
    $hash{$snp}{"chr"}=$chr;
#    $hash{$snp}{"bp"}=$bp;

    push @{$ordered{$bp}},$snp;
}

close($F1);

#print Dumper(%hash);

## 06 chr6:63854:T:G 0 63854 T G
# open(my $F2, "ukbb_bimfiles/ukb_v3_imp_".$chr."_afr_snptest.bim");

# while(my $l = <$F2>){
#     chomp $l;
#     my @d = split " ", $l;
#     my $snptest = $d[1]; my $bp = $d[3];
#     my $a1 = $d[4]; my $a2 = $d[5];

#     if(exists($hash{$snptest})){
# 	$hash{$snptest}{"bp"}=$bp;
# 	$hash{$snptest}{"a1"}=$a1;
# 	$hash{$snptest}{"a2"}=$a2;
#     }
# }

# close($F2);

# 06 rs544586840 0 63854 T G
open(my $F3, "ukbb_bimfiles/ukb_v3_imp_".$chr."_afr.bim");

while(my $l = <$F3>){
    chomp $l;
    my @d = split " ", $l;
    my $snp = $d[1];
    my $bp = $d[3]; my $a1 = $d[4]; my $a2 = $d[5];
    my $snptest1="chr".$chr.":".$bp.":".$a1.":".$a2;
    my $snptest2="chr".$chr.":".$bp.":".$a2.":".$a1;

    if(exists($hash{$snptest1})){
	$hash{$snptest1}{"rsid"}=$snp;
    }
    elsif(exists($hash{$snptest2})){
	$hash{$snptest2}{"rsid"}=$snp;
    }
}

close($F3);

open(my $O, "> LZ/$name.metal");
open(my $MAP, "> $name.rsid.map");
print $O "MarkerName\tP-value\n";

foreach my $bp (sort{$a<=>$b}(keys(%ordered))){
   foreach my $snptest (@{$ordered{$bp}}){
       my $rsid = $hash{$snptest}{"rsid"};
       my $p = $hash{$snptest}{"p"};

       print $O "$rsid\t$p\n";
       print $MAP "$rsid\t$snptest\n";
    }
}

close($O);
close($O);

#print Dumper(%ordered);
