#!/usr/bin/perl

use strict;
use warnings;
use Data::Dumper;

my %hash = ();

#Chr     SNP     bp      A1      A2      Freq    b       se      p       N
open(my $F, $ARGV[0]);
my $name = $ARGV[0]; $name=~s/\.txt//g;

<$F>;
while(my $l = <$F>){
    chomp($l);
    my @d = split "\t", $l;
    my $snptest=$d[1];
    $snptest=~/(.*)\:(.*)\:(.*)\:(.*)/;
    my $chr = $1;
    my $bp = $2;
    $chr=~s/chr//g;

    push @{$hash{$chr}{$bp}},  "chr$chr\t$bp\t".($bp+1)."\t$snptest";
}

close($F);

#print Dumper(%hash);

## chr10   29458447        29458448        chr10:29458448_CG_C  
open(my $O, "> working/$name.b38.bed");

foreach my $ch (sort{$a<=>$b}(keys(%hash))){
    foreach my $bp (sort{$a<=>$b}(keys(%{$hash{$ch}}))){
	foreach my $l (@{$hash{$ch}{$bp}}){
	    print $O "$l\n";
	}
    }
}
close($O);
