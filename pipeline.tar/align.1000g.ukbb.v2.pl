#!/usr/bin/perl

use strict;
use warnings;
use Data::Dumper;

my %fliphash = (
    "A"=>"T",
    "T"=>"A",
    "C"=>"G",
    "G"=>"C",
);

my %hash = ();

my $root = $ARGV[0];
my $chr = $ARGV[1]; my $st = $ARGV[2]; my $en = $ARGV[3];

## 22      rs12172168      0       16050822        A       G
open(my $F1, "$root/ukb_v3_imp_".$chr."_afr_snptest.bim");

while(my $l = <$F1>){
    chomp $l;
    #print "$l\n";
    my @d = split " ", $l;
    my $snp = $d[1];
    my $bp = $d[3]; my $a1 = $d[4]; my $a2 = $d[5];
#    print "$bp\n";

    if($bp >= $st && $bp <= $en){
   	my $snptest1 = $chr.":".$bp.":".$a1.":".$a2;
   	my $snptest2 = $chr.":".$bp.":".$a2.":".$a1;

   	$hash{$snptest1}{"snp"} = $snp;
   	$hash{$snptest2}{"snp"} = $snp;
   }
}

close($F1);

#print Dumper(%hash);
my $file = $ARGV[4];

my $name = $file;
$name=~s/\.ma//g;

## SNP A1 A2 freq b se p N chr bp
open(my $F, "$file");
open(my $O, ">" . $name . ".ukbb_aligned.ma");
open(my $LOG, ">working/".$name.".ukbb_aligned.log");

my $h = <$F>; chomp $h;
print $O "$h\n";

while(my $l = <$F>){
    chomp $l;   
    my ($id, $a1, $a2, $freq, $b, $se, $p, $n, $chr, $bp) = split " ", $l;

    my $snptest = $chr.":".$bp.":".$a1.":".$a2;

    if(exists($hash{$snptest}) ){ 	
	my $snp = $hash{$snptest}{"snp"};
	print $O "$snp $a1 $a2 $freq $b $se $p $n $chr $bp\n";
    }
    elsif(length($a1) == 1 && length($a2) == 1){ 	
	my $flipa1 = $fliphash{$a1};
	my $flipa2 = $fliphash{$a2};
	my $snptest_flip = $chr.":".$bp.":".$flipa1.":".$flipa2;
	if(exists($hash{$snptest_flip})){
	    print $LOG "FLIPPED $snptest_flip $snptest\n";
	    my $snp = $hash{$snptest_flip}{"snp"};
	    print $O "$snp $flipa1 $flipa2 $freq $b $se $p $n $chr $bp\n";
	}
	else{
	    print $LOG "NOMATCH $snptest\n";
	}
    }
    else{
	print $LOG "NOMATCH $snptest\n";
    }
}

close($F);
close($O);
close($LOG);
