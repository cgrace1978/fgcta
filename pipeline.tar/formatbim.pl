#!/usr/bin/perl

use strict;
use warnings;

my $targetdir=$ARGV[0];
my $chrin=$ARGV[1];
my $rootdir="/well/PROCARDIS/agoel/ukbb_full/ld/afr";

if(!(-d $targetdir)){
    `mkdir $targetdir`;
}

if(!(-e "$targetdir/ukb_v3_imp_".$chrin."_afr.fam")){
    my $cmd1 = "cp $rootdir/*\_$chrin\_*.bed $targetdir";
    my $cmd2 = "cp $rootdir/*\_$chrin\_*.bim $targetdir";
    my $cmd3 = "cp $rootdir/*\_$chrin\_*.fam $targetdir";
    print "$cmd1\n"; `$cmd1`;
    print "$cmd2\n"; `$cmd2`;
    print "$cmd3\n"; `$cmd3`;
}

if(!(-e "$targetdir/ukb_v3_imp_".$chrin."_afr_snptest.bim")){
    ## 22 rs587697622 0 16050075 A G
    open(my $F, "$targetdir/ukb_v3_imp_".$chrin."_afr.bim");
    open(my $O, "> $targetdir/ukb_v3_imp_".$chrin."_afr_snptest.bim");

    while(my $l = <$F>){
	chomp $l;
	my ($chr, $snp, $cm, $bp, $a1, $a2) = split " ", $l;
	my $chrold=$chr;
	$chr=~s/^0//g;
	my $id = "chr".$chr.":".$bp.":".$a1.":".$a2;
	print $O "$chrold $id $cm $bp $a1 $a2\n";
    }

    close($F);
    close($O);
}

if(!(-e "$targetdir/ukb_v3_imp_".$chrin."_afr_snptest.fam")){
    my $cmd4 = "cp $targetdir/ukb_v3_imp_".$chrin."_afr.bed $targetdir/ukb_v3_imp_".$chrin."_afr_snptest.bed";
    my $cmd5 = "cp $targetdir/ukb_v3_imp_".$chrin."_afr.fam $targetdir/ukb_v3_imp_".$chrin."_afr_snptest.fam";

    print "$cmd4\n";
    `$cmd4`;
    print "$cmd5\n";
    `$cmd5`;
}
