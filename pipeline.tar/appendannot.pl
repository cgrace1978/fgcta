#!/usr/bin/perl

use strict;
use warnings;
use Data::Dumper;

my %annot = ();

my $file=$ARGV[0];
my $name=$file; $name=~s/\.ma//g;
my $annot=$ARGV[1];

##CHR     POS0    POS     SNPID   HUDEP2
open(my $F1, "annotation/$name.$annot.txt");

<$F1>;
while(my $l = <$F1>){
    chomp $l;
    my ($chr, $pos0, $pos, $snp, $annotval) = split "\t", $l;

    $annot{$snp}{"val"} = $annotval;
}

close($F1);

#print Dumper(%annot);

## SNP A1 A2 freq b se p N chr bp
open(my $F2, $file);
open(my $O, "> $name.$annot.ma");

my $h2 = <$F2>; chomp $h2;
print $O "$h2 $annot\n";

while(my $l = <$F2>){
    chomp $l;
    my @d = split " ", $l;
    my $snp = $d[0];

    if(!exists($annot{$snp})){
	print STDERR "No SNP found!\n";
	last;
    }

    my $annotval = $annot{$snp}{"val"};
    print $O "$l $annotval\n";
}

close($F2);
close($O);
