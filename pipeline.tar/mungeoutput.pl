#!/usr/bin/perl

use strict;
use warnings;
use Data::Dumper;

my %hash = ();
my @h = ();

opendir(my $D, "output");

my @files = grep(/\.jma\.cojo/,readdir($D));
foreach my $file (sort(@files)){
    my $name = $file; $name=~s/\.jma\.cojo//g;
    my @parts = split '\.', $name;
    my $name1=$parts[0];
    $name=~s/$name1\.b37\.ukbb_aligned\.//g;
    my $pval = $name; my $annot = "NA"; my $dum="NA";
    if($name=~/x2\_5/){
	($annot, $dum, my $pval1, my $pval2) = split '\.', $name;
	if(defined($pval2)){
	    $pval=$pval1.".".$pval2;
	}
	else{
	    $pval=$pval1;
	}
    }

    $hash{$name1}{$annot}{$pval}{"init"}++;
    ## Chr     SNP     bp      refA    freq    b       se      p       n       freq_geno       bJ      bJ_se   pJ      LD_r
    open(my $F, "output/$file");

    my $h = <$F>; chomp $h;
    @h = split "\t", $h;
    while(my $l = <$F>){
	chomp $l;
	my @d = split "\t", $l;
	my %subhash = ();
	for(my $i = 0; $i < scalar(@h); $i++){
	    $subhash{$h[$i]}=$d[$i];
	}

	push @{$hash{$name1}{$annot}{$pval}{"jma"}}, \%subhash;
    }   

    close($F);
}

close($D);

#print Dumper(%hash);

print "LOCUS\tANNOT\tPVAL\t";
my $h = "";
for(my $i = 0; $i < scalar(@h); $i++){
    $h.=$h[$i]."\t";
}
chop $h;
print "$h\n";
foreach my $name (sort(keys(%hash))){    
    foreach my $annot (sort(keys(%{$hash{$name}}))){
	foreach my $pval (sort(keys(%{$hash{$name}{$annot}}))){
	    foreach my $subhash(@{$hash{$name}{$annot}{$pval}{"jma"}}){
		my $l = "";
		for(my $i = 0; $i < scalar(@h); $i++){
		    $l.=$$subhash{$h[$i]}."\t";
		}
		chop $l;
		print "$name\t$annot\t$pval\t$l\n";    
	    }
	}	
    }
}
