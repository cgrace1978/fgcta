#!/bin/bash

sno=$1
file=`grep -w ^$sno in.ma.txt1 | cut -f 2`
chr=`grep -w ^$sno in.ma.txt1 | cut -f 3`
st=`grep -w ^$sno in.ma.txt1 | cut -f 5`
en=`grep -w ^$sno in.ma.txt1 | cut -f 6`

name=`echo $file | sed 's/\.txt//g'`

## munging of *.ma files?
# liftover the files.
echo -ne "Converting summ stats: $file from b38 to b37...\n"
perl pipeline/mungeliftover.pl $file

/well/PROCARDIS/bin/liftover/liftOver working/$name.b38.bed \
    /well/PROCARDIS/bin/liftover/hg38ToHg19.over.chain.gz \
    working/$name.b37.bed working/$name.unlifted.bed

perl pipeline/mungeliftover.out.pl $file

# echo -ne "Converting summ stats to ma format: $name.b37.ma...\n"
# perl pipeline/munge.ma.pl working/${name}.b37.txt

# # # ## munging of annotation files?
# # # genchromhmminput.pl # filters the chromhmm input by state
# ## just use generated files for now.

# # ## convert UKBB files to use SNPTEST IDs
# echo -ne "aligning with UKBB files: $name.b37.ukbb_aligned.ma...\n"
# perl pipeline/formatbim.pl ukbb_bimfiles $chr # adds SNPTEST IDs to UKBB bim files.

# # ## align the *.ma files with the UKBB files
# perl pipeline/align.1000g.ukbb.v2.pl ukbb_bimfiles $chr $st $en $name.b37.ma

# # ## generate the FGWAS input file.
# # #munge-snps.pl # formats the *.ma files for use with build_fgwas.pl
# # #build_fgwas.pl # formats SNPs and annotation files into format for use with FGWAS.
# echo -ne "Merging with annotation files: $name.b37.ukbb_aligned.HUDEP-2.ma,$name.b37.ukbb_aligned.E123.ma...\n"
# perl pipeline/munge-snps.pl $name.b37.ukbb_aligned.ma
# perl pipeline/build_fgwas.pl $name.b37.ukbb_aligned.in.bed $chr HUDEP-2
# perl pipeline/build_fgwas.pl $name.b37.ukbb_aligned.in.bed $chr E123

# # ## add annotation to the *.ma files
# # appendannot.pl # adds annot status to te *.ma file from the FGWAS bed file.
# perl pipeline/appendannot.pl $name.b37.ukbb_aligned.ma HUDEP-2
# perl pipeline/appendannot.pl $name.b37.ukbb_aligned.ma E123

# # ## scale *.ma files
# # bayesianv2 # executable to perform the bayesian scaling.
# echo -ne "Performing Bayesian Scaling: $name.b37.ukbb_aligned.HUDEP-2.x2_5.ma,$name.b37.ukbb_aligned.E123.x2_5.ma 2.5...\n"
# ./pipeline/bayesianv2 $name.b37.ukbb_aligned.HUDEP-2.ma $name.b37.ukbb_aligned.HUDEP-2.x2_5.ma 2.5
# ./pipeline/bayesianv2 $name.b37.ukbb_aligned.E123.ma $name.b37.ukbb_aligned.E123.x2_5.ma 2.5

# # ## run GCTA
# # #rungcta64_simGWAS.bash # runs GCTA on the scaled input files *.ma
# echo -ne "Running GCTA...\n"
# bash pipeline/rungcta64_simGWAS.bash $chr $name.b37.ukbb_aligned.ma 0.05 x2_5 HUDEP-2,E123
# bash pipeline/rungcta64_simGWAS.bash $chr $name.b37.ukbb_aligned.ma 1E-5 x2_5 HUDEP-2,E123

# # ## munging of results?
# # ## LZ plots?
# bash pipeline/LZ.bash $sno
# perl pipeline/mungeoutput.pl
