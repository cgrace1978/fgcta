#!/usr/bin/perl

use strict;
use warnings;
use Data::Dumper;

my %hash = ();

#Chr     SNP     bp      A1      A2      Freq    b       se      p       N
open(my $F1, $ARGV[0]);
my $name = $ARGV[0]; $name=~s/\.txt//g;

<$F1>;
while(my $l = <$F1>){
    chomp($l);
    my ($chr, $snp_b38, $bp, $a1, $a2, $freq, $b, $se, $p, $n) = split "\t", $l;

    my %subhash = ();
    $subhash{"b38"}=$snp_b38;
    $subhash{"a1"}=$a1;
    $subhash{"a2"}=$a2;
    $subhash{"freq"}=$freq;
    $subhash{"b"}=$b;
    $subhash{"se"}=$se;
    $subhash{"p"}=$p;
    $subhash{"n"}=$n;
    $subhash{"bp_b38"}=$bp;

    push @{$hash{$chr}{$bp}},  \%subhash;
}

close($F1);

#print Dumper(%hash);

## chr2    60459545        60459546        chr2:60459545:C:A
open(my $F2, "working/$name.b37.bed");

while(my $l = <$F2>){
    chomp($l);
    my ($chr, $bp, $dm, $b38snp) = split "\t", $l; $chr=~s/chr//g;
    $b38snp=~/(.*)\:(.*)\:(.*)\:(.*)/;
    my $b38bp=$2; my $a1=$3; my $a2=$4;

    if(!exists($hash{$chr}{$b38bp})){
    	print STDERR "Not found!\n";
    }

    for(my $i = 0; $i < scalar(@{$hash{$chr}{$b38bp}}); $i++){
    	if($b38snp eq $hash{$chr}{$b38bp}[$i]{"b38"}){
    	    $hash{$chr}{$b38bp}[$i]{"b37"} = "chr".$chr.":".$bp.":".$a1.":".$a2;
	    $hash{$chr}{$b38bp}[$i]{"bp_b37"} = $bp;
    	}
    }
}

close($F2);

#print Dumper(%hash);

#Chr     SNP     bp      A1      A2      Freq    b       se      p       N
open(my $O, "> working/$name.b37.txt");
print $O "Chr\tSNP\tbp_b37\tA1\tA2\tFreq\tb\tse\tp\tN\tbp_b38\n";
foreach my $chr (sort{$a<=>$b}(keys(%hash))){
    foreach my $bp_b38 (sort{$a<=>$b}(keys(%{$hash{$chr}}))){
	foreach my $subhash (@{$hash{$chr}{$bp_b38}}){	    
	    my $bp_b37 = $$subhash{"bp_b37"};
	    my $snp_b37 = $$subhash{"b37"};
	    my $a1 = $$subhash{"a1"};
	    my $a2 = $$subhash{"a2"};
	    my $freq = $$subhash{"freq"};
	    my $b = $$subhash{"b"};
	    my $se = $$subhash{"se"};
	    my $p = $$subhash{"p"};
	    my $n = $$subhash{"n"};
	    print $O "$chr\t$snp_b37\t$bp_b37\t$a1\t$a2\t$freq\t$b\t$se\t$p\t$n\t$bp_b38\n";
	}
    }
}

close($O);
#print Dumper(%hash);
