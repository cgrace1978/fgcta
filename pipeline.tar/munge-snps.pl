#!/usr/bin/perl

use strict;
use warnings;

my $file = $ARGV[0];
my $name = $file;
$name=~s/\.ma//g;

## SNP A1 A2 freq b se p N chr bp
open(my $F, $file);
open(my $O, "> working/$name.in.bed");

<$F>;
while(my $l = <$F>){
    chomp $l;
    my @d = split " ", $l;

    my $chr = $d[8]; my $bp = $d[9];
    my $snp = $d[0];
    my $bp0 = $bp - 1;

    print $O "chr$chr\t$bp0\t$bp\t$snp\n";
}

close($F);
close($O);
